"""Lidarr diagnostics and album-search outcome classification."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import logging
from pathlib import Path
from typing import Any, Iterable

from plex_playlist.lidarr_client import LidarrClient
from plex_playlist.models import MatchResult
from plex_playlist.normalization import normalize_artist, normalize_title

logger = logging.getLogger("plex_playlist")


TRACK_ALREADY_AVAILABLE = "TRACK_ALREADY_AVAILABLE"
TRACK_NOT_IN_LIDARR_METADATA = "TRACK_NOT_IN_LIDARR_METADATA"
ARTIST_NOT_MANAGED = "ARTIST_NOT_MANAGED"
ARTIST_AMBIGUOUS = "ARTIST_AMBIGUOUS"
NO_ARTIST_CANDIDATE = "NO_ARTIST_CANDIDATE"
SEARCH_NOT_REQUESTED = "SEARCH_NOT_REQUESTED"
SEARCH_QUEUED = "SEARCH_QUEUED"
SEARCH_COMPLETED_FILE_AVAILABLE = "SEARCH_COMPLETED_FILE_AVAILABLE"
SEARCH_COMPLETED_NO_FILE = "SEARCH_COMPLETED_NO_FILE"
SEARCH_FAILED = "SEARCH_FAILED"
SEARCH_STATUS_UNAVAILABLE = "SEARCH_STATUS_UNAVAILABLE"


@dataclass(frozen=True, slots=True)
class LidarrDiagnosticRow:
    sequence: int
    requested_artist: str
    requested_title: str
    lidarr_status: str
    matched_lidarr_artist: str
    musicbrainz_artist_id: str
    lidarr_artist_id: int | None
    already_managed: bool
    candidate_count: int
    matched_album: str
    matched_track: str
    album_id: int | None
    album_search_requested: bool
    album_search_command_id: int | None
    album_search_status: str
    acquisition_status: str
    track_id: int | None
    track_found: bool
    track_file_available: bool
    recommended_action: str
    notes: str


def build_lidarr_diagnostics(
    *,
    results: Iterable[MatchResult],
    client: LidarrClient,
    search_missing_albums: bool = False,
    wait_for_search_seconds: float = 0.0,
    search_poll_interval_seconds: float = 2.0,
) -> list[LidarrDiagnosticRow]:
    rows: list[LidarrDiagnosticRow] = []
    lookup_cache: dict[str, list[dict[str, Any]]] = {}
    managed_cache: dict[str, dict[str, Any] | None] = {}
    artist_media_cache: dict[
        int, tuple[list[dict[str, Any]], list[dict[str, Any]]]
    ] = {}
    searched_albums: dict[int, tuple[int | None, str, str]] = {}

    for result in results:
        if result.matched is not None:
            continue

        entry = _requested_entry(result)
        artist_key = normalize_artist(entry.artist)
        if artist_key not in lookup_cache:
            lookup_cache[artist_key] = client.lookup_artist(entry.artist)
        candidates = lookup_cache[artist_key]

        best, managed = _resolve_artist(
            requested_artist=entry.artist,
            candidates=candidates,
            client=client,
            managed_cache=managed_cache,
        )

        if managed is None:
            rows.append(
                _unmanaged_row(
                    result=result,
                    entry=entry,
                    candidates=candidates,
                    best=best,
                )
            )
            continue

        lidarr_artist_id = _lidarr_artist_id(managed)
        albums: list[dict[str, Any]] = []
        tracks: list[dict[str, Any]] = []
        if lidarr_artist_id is not None:
            if lidarr_artist_id not in artist_media_cache:
                artist_media_cache[lidarr_artist_id] = (
                    client.get_artist_albums(lidarr_artist_id),
                    client.get_artist_tracks(lidarr_artist_id),
                )
            albums, tracks = artist_media_cache[lidarr_artist_id]

        found_track = _find_track(
            requested_title=entry.title,
            tracks=tracks,
        )
        found_album = _find_track_album(found_track, albums)
        track_available = (
            _track_has_file(found_track) if found_track is not None else False
        )
        album_id = _album_id(found_album) if found_album is not None else None

        search_requested = False
        command_id: int | None = None
        search_status = ""
        acquisition_status, action = _base_track_status(
            found_track=found_track,
            track_available=track_available,
            search_missing_albums=search_missing_albums,
        )

        if (
            search_missing_albums
            and found_track is not None
            and not track_available
            and album_id is not None
        ):
            if album_id in searched_albums:
                command_id, search_status, acquisition_status = (
                    searched_albums[album_id]
                )
                action = "Album search already handled during this run"
            else:
                command = client.search_album(album_id)
                search_requested = True
                command_id = _optional_int(command.get("id"))
                search_status = str(command.get("status", "") or "queued")
                acquisition_status = SEARCH_QUEUED
                action = "Album search queued in Lidarr"

                if command_id is not None and wait_for_search_seconds > 0:
                    command_status = client.wait_for_command(
                        command_id,
                        timeout_seconds=wait_for_search_seconds,
                        poll_interval_seconds=search_poll_interval_seconds,
                    )
                    search_status = command_status.status
                    if command_status.completed and not command_status.successful:
                        acquisition_status = SEARCH_FAILED
                        action = (
                            command_status.message
                            or "Lidarr album search command failed"
                        )
                    elif command_status.successful:
                        # Re-read tracks after the completed command.  A completed
                        # Lidarr command means the search ran; it does not prove
                        # that an acceptable release was found or downloaded.
                        refreshed_tracks = client.get_artist_tracks(
                            lidarr_artist_id
                        )
                        artist_media_cache[lidarr_artist_id] = (
                            albums,
                            refreshed_tracks,
                        )
                        found_track = _find_track(
                            requested_title=entry.title,
                            tracks=refreshed_tracks,
                        )
                        track_available = (
                            _track_has_file(found_track)
                            if found_track is not None
                            else False
                        )
                        if track_available:
                            acquisition_status = SEARCH_COMPLETED_FILE_AVAILABLE
                            action = (
                                "Track acquired; refresh Plex and retry matching"
                            )
                        else:
                            acquisition_status = SEARCH_COMPLETED_NO_FILE
                            action = (
                                "Search completed but no track file is available; "
                                "send to the TIDAL companion playlist"
                            )
                    else:
                        acquisition_status = SEARCH_QUEUED
                        action = (
                            "Lidarr search is still running; retry on the next sync"
                        )
                elif command_id is None:
                    acquisition_status = SEARCH_STATUS_UNAVAILABLE
                    action = (
                        "Lidarr accepted the search but returned no command ID"
                    )

                searched_albums[album_id] = (
                    command_id,
                    search_status,
                    acquisition_status,
                )
                logger.info(
                    "Lidarr album search: %s - %s "
                    "(album ID %s, command ID %s, outcome %s)",
                    entry.artist,
                    _album_title(found_album),
                    album_id,
                    command_id if command_id is not None else "unknown",
                    acquisition_status,
                )

        lidarr_status = _human_track_status(found_track, track_available)
        rows.append(
            LidarrDiagnosticRow(
                sequence=entry.sequence,
                requested_artist=entry.artist,
                requested_title=entry.title,
                lidarr_status=lidarr_status,
                matched_lidarr_artist=_artist_name(managed),
                musicbrainz_artist_id=_foreign_artist_id(managed),
                lidarr_artist_id=lidarr_artist_id,
                already_managed=True,
                candidate_count=len(candidates),
                matched_album=(
                    _album_title(found_album) if found_album is not None else ""
                ),
                matched_track=(
                    _track_title(found_track) if found_track is not None else ""
                ),
                album_id=album_id,
                album_search_requested=search_requested,
                album_search_command_id=command_id,
                album_search_status=search_status,
                acquisition_status=acquisition_status,
                track_id=(
                    _track_id(found_track) if found_track is not None else None
                ),
                track_found=found_track is not None,
                track_file_available=track_available,
                recommended_action=action,
                notes=str(getattr(result, "reason", "") or ""),
            )
        )

    return rows


def write_lidarr_diagnostic_csv(
    rows: Iterable[LidarrDiagnosticRow],
    output_path: Path,
) -> None:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    headers = [
        "Sequence", "Requested Artist", "Requested Title", "Lidarr Status",
        "Matched Lidarr Artist", "MusicBrainz Artist ID", "Lidarr Artist ID",
        "Already Managed", "Candidate Count", "Matched Album", "Matched Track",
        "Album ID", "Track ID", "Track Found", "Track File Available",
        "Album Search Requested", "Album Search Command ID",
        "Album Search Status", "Acquisition Status", "Recommended Action",
        "Notes",
    ]
    with output_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        for row in rows:
            writer.writerow([
                row.sequence, row.requested_artist, row.requested_title,
                row.lidarr_status, row.matched_lidarr_artist,
                row.musicbrainz_artist_id,
                row.lidarr_artist_id if row.lidarr_artist_id is not None else "",
                "Yes" if row.already_managed else "No", row.candidate_count,
                row.matched_album, row.matched_track,
                row.album_id if row.album_id is not None else "",
                row.track_id if row.track_id is not None else "",
                "Yes" if row.track_found else "No",
                "Yes" if row.track_file_available else "No",
                "Yes" if row.album_search_requested else "No",
                (
                    row.album_search_command_id
                    if row.album_search_command_id is not None else ""
                ),
                row.album_search_status, row.acquisition_status,
                row.recommended_action, row.notes,
            ])


def _resolve_artist(
    *,
    requested_artist: str,
    candidates: list[dict[str, Any]],
    client: LidarrClient,
    managed_cache: dict[str, dict[str, Any] | None],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    exact = _exact_artist_candidates(
        requested_artist=requested_artist,
        candidates=candidates,
    )
    considered = exact if exact else (candidates if len(candidates) == 1 else [])
    if not considered:
        return None, None

    managed_matches: list[
        tuple[dict[str, Any], dict[str, Any]]
    ] = []
    for candidate in considered:
        mbid = _foreign_artist_id(candidate)
        if not mbid:
            continue
        if mbid not in managed_cache:
            managed_cache[mbid] = client.get_managed_artist_by_mbid(mbid)
        managed = managed_cache[mbid]
        if managed is not None:
            managed_matches.append((candidate, managed))

    if len(managed_matches) == 1:
        return managed_matches[0]

    if len(considered) == 1:
        return considered[0], None

    return None, None


def _unmanaged_row(*, result: Any, entry: Any, candidates: list[dict[str, Any]],
                   best: dict[str, Any] | None) -> LidarrDiagnosticRow:
    if not candidates:
        status = "No candidate"
        acquisition = NO_ARTIST_CANDIDATE
        action = "Review artist spelling or search Lidarr manually"
    elif best is None:
        status = "Multiple candidates"
        acquisition = ARTIST_AMBIGUOUS
        action = "Select the correct Lidarr artist manually"
    else:
        status = "Lookup candidate found"
        acquisition = ARTIST_NOT_MANAGED
        action = "Review candidate before adding to Lidarr"

    return LidarrDiagnosticRow(
        sequence=entry.sequence,
        requested_artist=entry.artist,
        requested_title=entry.title,
        lidarr_status=status,
        matched_lidarr_artist=_artist_name(best) if best is not None else "",
        musicbrainz_artist_id=(
            _foreign_artist_id(best) if best is not None else ""
        ),
        lidarr_artist_id=None,
        already_managed=False,
        candidate_count=len(candidates),
        matched_album="",
        matched_track="",
        album_id=None,
        album_search_requested=False,
        album_search_command_id=None,
        album_search_status="",
        acquisition_status=acquisition,
        track_id=None,
        track_found=False,
        track_file_available=False,
        recommended_action=action,
        notes=str(getattr(result, "reason", "") or ""),
    )


def _base_track_status(
    *,
    found_track: dict[str, Any] | None,
    track_available: bool,
    search_missing_albums: bool,
) -> tuple[str, str]:
    if found_track is None:
        return (
            TRACK_NOT_IN_LIDARR_METADATA,
            "Review the artist's albums in Lidarr and identify the release",
        )
    if track_available:
        return (
            TRACK_ALREADY_AVAILABLE,
            "Refresh the Plex library or review Plex metadata",
        )
    if search_missing_albums:
        return SEARCH_NOT_REQUESTED, "Matching album could not be searched"
    return (
        SEARCH_NOT_REQUESTED,
        "Run with --lidarr-search to search the matching album",
    )


def _human_track_status(
    found_track: dict[str, Any] | None,
    track_available: bool,
) -> str:
    if found_track is None:
        return "Artist managed; track not found"
    if track_available:
        return "Track found with file"
    return "Track found; file missing"


def _requested_entry(result: MatchResult) -> Any:
    requested = getattr(result, "requested", None)
    if requested is not None:
        return requested
    entry = getattr(result, "entry", None)
    if entry is not None:
        return entry
    raise AttributeError("Match result has neither 'requested' nor 'entry'")


def _find_track_album(
    track: dict[str, Any] | None,
    albums: list[dict[str, Any]],
) -> dict[str, Any] | None:
    if track is None:
        return None
    album_id = _track_album_id(track)
    return next(
        (album for album in albums if _album_id(album) == album_id),
        None,
    )


def _find_track(
    *,
    requested_title: str,
    tracks: list[dict[str, Any]],
) -> dict[str, Any] | None:
    requested_key = normalize_title(requested_title)
    exact = [
        track for track in tracks
        if normalize_title(_track_title(track)) == requested_key
    ]
    if not exact:
        return None
    exact.sort(
        key=lambda item: (
            not _track_has_file(item),
            _track_id(item) or 0,
        )
    )
    return exact[0]


def _exact_artist_candidates(
    *,
    requested_artist: str,
    candidates: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    requested_key = normalize_artist(requested_artist)
    return [
        candidate for candidate in candidates
        if normalize_artist(_artist_name(candidate)) == requested_key
    ]


def _artist_name(item: dict[str, Any]) -> str:
    return str(item.get("artistName", "") or item.get("title", "") or "")


def _foreign_artist_id(item: dict[str, Any]) -> str:
    return str(item.get("foreignArtistId", "") or "")


def _lidarr_artist_id(item: dict[str, Any]) -> int | None:
    return _optional_int(item.get("id"))


def _track_title(item: dict[str, Any]) -> str:
    return str(item.get("title", "") or item.get("trackTitle", "") or "")


def _track_id(item: dict[str, Any]) -> int | None:
    return _optional_int(item.get("id"))


def _track_album_id(item: dict[str, Any]) -> int | None:
    return _optional_int(item.get("albumId"))


def _track_has_file(item: dict[str, Any]) -> bool:
    if bool(item.get("hasFile", False)):
        return True
    return (_optional_int(item.get("trackFileId")) or 0) > 0


def _album_title(item: dict[str, Any]) -> str:
    return str(item.get("title", "") or item.get("albumTitle", "") or "")


def _album_id(item: dict[str, Any]) -> int | None:
    return _optional_int(item.get("id"))


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
