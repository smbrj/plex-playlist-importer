# Plex Playlist Importer v2.4.1 — Lidarr Resilience and Progress

## Included changes

- Lidarr API request timing messages move from `INFO` to `DEBUG`.
- A failed Lidarr request affects only the current unmatched entry.
- Processing continues with later entries.
- Failed entries are retained in the Lidarr CSV report with:
  - `Lidarr Status = Lidarr request failed`
  - `Acquisition Status = REQUEST_FAILED`
  - `Recommended Action = Retry on a later run`
- INFO logging now reports:
  - unmatched entry count
  - `Unique artists: nn`
  - periodic `Lidarr progress: x/y`
  - the existing final acquisition summary

Unexpected programming errors are deliberately not swallowed. Only
`LidarrError` request/response failures are isolated.

## Install

Extract the archive into the project root. Copy:

```text
apply_v2_4_1.py
tests/test_lidarr_resilience_v2_4_1.py
```

Then run:

```powershell
python apply_v2_4_1.py .
```

Backups are created automatically:

```text
plex_playlist/lidarr_client.py.v2_4_1_backup
plex_playlist/lidarr_reporting.py.v2_4_1_backup
playlist_import_v2.py.v2_4_1_backup
```

## Expected INFO output

```text
Lidarr diagnostics starting: 58 unmatched entries; Unique artists: 41
Lidarr progress: 1/58
Lidarr progress: 5/58
Lidarr progress: 10/58
...
Lidarr progress: 58/58
Lidarr diagnostics complete: 58 unmatched entries
Lidarr acquisition summary: ... REQUEST_FAILED=1 ...
```

The exact progress interval is approximately ten updates per run, plus
the first and final entry.

## DEBUG output

With `[logging] level = DEBUG`, detailed timings remain available:

```text
Lidarr API GET artist/lookup completed in 0.42 sec
Lidarr API GET artist completed in 0.03 sec
```

## Test

Focused:

```powershell
python -m pytest tests/test_lidarr_resilience_v2_4_1.py -v
```

Full:

```powershell
python -m pytest -v
```

## Scope boundary

This cycle does not add automatic HTTP retries. A transient failure is
recorded and deferred to the next scheduled importer run. That avoids
multiplying Lidarr traffic during a degraded-service event.
