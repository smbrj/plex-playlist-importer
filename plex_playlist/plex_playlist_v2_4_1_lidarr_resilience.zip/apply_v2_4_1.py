from __future__ import annotations

import sys
from pathlib import Path


NEW_BUILD_FUNCTION = r'''def build_lidarr_diagnostics(
    *,
    results: Iterable[MatchResult],
    client: LidarrClient,
    search_missing_albums: bool = False,
    wait_for_search_seconds: float = 0.0,
    search_poll_interval_seconds: float = 2.0,
    history_store: LidarrSearchHistoryStore | None = None,
    remember_searches: bool = True,
    retry_after_days: float = 7.0,
    progress_callback: Callable[[int, int, Any], None] | None = None,
) -> list[LidarrDiagnosticRow]:
    # Expected Lidarr request failures are isolated to one entry.
    # Unexpected programming errors still propagate.

    service = LidarrAcquisitionService(
        client=client,
        history_store=history_store,
        remember_searches=remember_searches,
        retry_after_days=retry_after_days,
    )
    rows: list[LidarrDiagnosticRow] = []
    unmatched_results = [
        result for result in results if result.matched is None
    ]
    total = len(unmatched_results)

    for completed, result in enumerate(unmatched_results, start=1):
        entry = _requested_entry(result)
        try:
            resolution = service.resolve(
                requested_artist=entry.artist,
                requested_title=entry.title,
            )

            if resolution.managed_artist is None:
                rows.append(_unmanaged_row(result, entry, resolution))
                continue

            decision = service.decide_search(
                requested_artist=entry.artist,
                resolution=resolution,
                search_missing_albums=search_missing_albums,
                wait_for_search_seconds=wait_for_search_seconds,
                search_poll_interval_seconds=search_poll_interval_seconds,
            )

            track = (
                decision.refreshed_track
                if decision.refreshed_track is not None
                else resolution.found_track
            )

            track_available = (
                decision.refreshed_track_available
                if decision.refreshed_track_available is not None
                else resolution.track_available
            )

            rows.append(
                LidarrDiagnosticRow(
                    sequence=entry.sequence,
                    requested_artist=entry.artist,
                    requested_title=entry.title,
                    lidarr_status=_human_track_status(
                        track, track_available
                    ),
                    matched_lidarr_artist=_artist_name(
                        resolution.managed_artist
                    ),
                    musicbrainz_artist_id=str(
                        resolution.managed_artist.get(
                            "foreignArtistId", ""
                        ) or ""
                    ),
                    lidarr_artist_id=resolution.lidarr_artist_id,
                    already_managed=True,
                    candidate_count=len(resolution.candidates),
                    matched_album=_album_title(resolution.found_album),
                    matched_track=_track_title(track),
                    album_id=resolution.album_id,
                    album_search_requested=decision.requested,
                    album_search_command_id=decision.command_id,
                    album_search_status=decision.search_status,
                    acquisition_status=decision.acquisition_status,
                    track_id=_optional_int(track.get("id")) if track else None,
                    track_found=track is not None,
                    track_file_available=track_available,
                    recommended_action=decision.recommended_action,
                    notes=str(getattr(result, "reason", "") or ""),
                )
            )
        except LidarrError as exc:
            rows.append(_request_failed_row(result, entry, exc))
        finally:
            if progress_callback is not None:
                progress_callback(completed, total, entry)

    return rows


def count_unique_unmatched_artists(
    results: Iterable[MatchResult],
) -> int:
    artists: set[str] = set()
    for result in results:
        if result.matched is not None:
            continue
        entry = _requested_entry(result)
        normalized = " ".join(
            str(entry.artist or "").casefold().split()
        )
        if normalized:
            artists.add(normalized)
    return len(artists)


'''

REQUEST_FAILED_HELPER = r'''def _request_failed_row(
    result: Any,
    entry: Any,
    exc: LidarrError,
) -> LidarrDiagnosticRow:
    return LidarrDiagnosticRow(
        sequence=entry.sequence,
        requested_artist=entry.artist,
        requested_title=entry.title,
        lidarr_status="Lidarr request failed",
        matched_lidarr_artist="",
        musicbrainz_artist_id="",
        lidarr_artist_id=None,
        already_managed=False,
        candidate_count=0,
        matched_album="",
        matched_track="",
        album_id=None,
        album_search_requested=False,
        album_search_command_id=None,
        album_search_status="",
        acquisition_status="REQUEST_FAILED",
        track_id=None,
        track_found=False,
        track_file_available=False,
        recommended_action="Retry on a later run",
        notes=(
            f"{str(getattr(result, 'reason', '') or '')}; "
            f"{exc}"
        ).strip("; "),
    )


'''

IMPORTER_START_BLOCK = r'''    unmatched_count = sum(
        1 for result in session.results
        if result.matched is None
    )
    unique_artist_count = count_unique_unmatched_artists(
        session.results
    )
    logger.info(
        "Lidarr diagnostics starting: %d unmatched entries; "
        "Unique artists: %d",
        unmatched_count,
        unique_artist_count,
    )

    progress_step = max(1, unmatched_count // 10)

    def log_progress(
        completed: int,
        total: int,
        _entry: object,
    ) -> None:
        if (
            completed == 1
            or completed == total
            or completed % progress_step == 0
        ):
            logger.info(
                "Lidarr progress: %d/%d",
                completed,
                total,
            )

    rows = build_lidarr_diagnostics(
        results=session.results,
        client=client,
        search_missing_albums=search_missing_albums,
        progress_callback=log_progress,
    )
'''


def replace_function(text: str, start: str, end: str, replacement: str) -> str:
    start_index = text.find(start)
    if start_index < 0:
        raise RuntimeError(f"Unable to find function start: {start!r}")
    end_index = text.find(end, start_index)
    if end_index < 0:
        raise RuntimeError(f"Unable to find function end: {end!r}")
    return text[:start_index] + replacement + text[end_index:]


def patch_lidarr_client(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    old = '''            logger.info(
                "Lidarr API %s %s completed in %.2f sec",
'''
    new = '''            logger.debug(
                "Lidarr API %s %s completed in %.2f sec",
'''
    if new in text:
        print(f"Already patched: {path}")
        return
    if old not in text:
        raise RuntimeError(
            "Unable to locate Lidarr API timing logger in "
            f"{path}"
        )
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"Patched: {path}")


def patch_lidarr_reporting(path: Path) -> None:
    text = path.read_text(encoding="utf-8")

    if "from typing import Any, Callable, Iterable" not in text:
        text = text.replace(
            "from typing import Any, Iterable",
            "from typing import Any, Callable, Iterable",
            1,
        )

    exception_import = "from plex_playlist.exceptions import LidarrError\n"
    if exception_import not in text:
        anchor = "from plex_playlist.lidarr_client import LidarrClient\n"
        if anchor not in text:
            raise RuntimeError("Unable to locate LidarrClient import")
        text = text.replace(
            anchor,
            anchor + exception_import,
            1,
        )

    if "def count_unique_unmatched_artists(" not in text:
        text = replace_function(
            text,
            "def build_lidarr_diagnostics(",
            "def write_lidarr_diagnostic_csv(",
            NEW_BUILD_FUNCTION,
        )

    if "def _request_failed_row(" not in text:
        anchor = "def _unmanaged_row("
        index = text.find(anchor)
        if index < 0:
            raise RuntimeError("Unable to locate _unmanaged_row")
        text = text[:index] + REQUEST_FAILED_HELPER + text[index:]

    path.write_text(text, encoding="utf-8")
    print(f"Patched: {path}")


def patch_importer(path: Path) -> None:
    text = path.read_text(encoding="utf-8")

    old_import = '''    LidarrDiagnosticRow,
    build_lidarr_diagnostics,
    write_lidarr_diagnostic_csv,
'''
    new_import = '''    LidarrDiagnosticRow,
    build_lidarr_diagnostics,
    count_unique_unmatched_artists,
    write_lidarr_diagnostic_csv,
'''
    if "count_unique_unmatched_artists," not in text:
        if old_import not in text:
            raise RuntimeError(
                "Unable to locate lidarr_reporting import block"
            )
        text = text.replace(old_import, new_import, 1)

    old_call = '''    rows = build_lidarr_diagnostics(
        results=session.results,
        client=client,
        search_missing_albums=search_missing_albums,
    )
'''
    if "Lidarr diagnostics starting:" not in text:
        if old_call not in text:
            raise RuntimeError(
                "Unable to locate build_lidarr_diagnostics call"
            )
        text = text.replace(old_call, IMPORTER_START_BLOCK, 1)

    path.write_text(text, encoding="utf-8")
    print(f"Patched: {path}")


def backup(path: Path) -> None:
    backup_path = path.with_suffix(
        path.suffix + ".v2_4_1_backup"
    )
    if not backup_path.exists():
        backup_path.write_bytes(path.read_bytes())
        print(f"Backup written: {backup_path}")


def main() -> int:
    project = (
        Path(sys.argv[1]).resolve()
        if len(sys.argv) > 1
        else Path.cwd().resolve()
    )

    targets = {
        "client": project / "plex_playlist" / "lidarr_client.py",
        "reporting": project / "plex_playlist" / "lidarr_reporting.py",
        "importer": project / "playlist_import_v2.py",
    }
    missing = [str(path) for path in targets.values() if not path.exists()]
    if missing:
        print("Missing required files:", file=sys.stderr)
        for item in missing:
            print(f"  {item}", file=sys.stderr)
        return 1

    for path in targets.values():
        backup(path)

    patch_lidarr_client(targets["client"])
    patch_lidarr_reporting(targets["reporting"])
    patch_importer(targets["importer"])

    print("v2.4.1 patch applied.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
